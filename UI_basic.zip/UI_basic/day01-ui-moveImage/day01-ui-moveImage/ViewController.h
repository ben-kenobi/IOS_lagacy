//
//  ViewController.h
//  day01-ui-moveImage
//
//  Created by apple on 15/9/11.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

