//
//  YFView.m
//  day14-ui-pwdmodal
//
//  Created by apple on 15/10/14.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import "YFView.h"

@implementation YFView

-(void)drawRect:(CGRect)rect{
   
}

@end
