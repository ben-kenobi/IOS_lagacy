//
//  YFAlerV.h
//  day14-ui-pwdmodal
//
//  Created by apple on 15/10/14.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFAlerV : UIView
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *message;
@end
