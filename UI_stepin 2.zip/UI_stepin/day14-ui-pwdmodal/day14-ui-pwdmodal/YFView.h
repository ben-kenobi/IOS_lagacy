//
//  YFView.h
//  day14-ui-pwdmodal
//
//  Created by apple on 15/10/14.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFView : UIView

@end
