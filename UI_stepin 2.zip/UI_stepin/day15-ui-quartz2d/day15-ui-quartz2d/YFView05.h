//
//  YFView05.h
//  day15-ui-quartz2d
//
//  Created by apple on 15/10/12.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFView05 : UIView

@end
