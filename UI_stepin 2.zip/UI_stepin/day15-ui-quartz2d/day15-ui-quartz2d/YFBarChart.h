//
//  YFBarChart.h
//  day15-ui-quartz2d
//
//  Created by apple on 15/10/9.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFBarChart : UIView

@property (nonatomic,assign)CGFloat max;
@property (nonatomic,strong)NSArray *datas;

@end
