//
//  YFView06.h
//  day15-ui-quartz2d
//
//  Created by apple on 15/10/12.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFView06 : UIView

@property (nonatomic,strong)BOOL (^blockDelegate)(NSString *);

@end
