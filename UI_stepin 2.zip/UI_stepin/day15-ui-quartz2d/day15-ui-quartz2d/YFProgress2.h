//
//  YFProgress2.h
//  day15-ui-quartz2d
//
//  Created by apple on 15/10/10.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFProgress2 : UIView

@property (nonatomic,assign)CGFloat perc;

@end
