//
//  YFView02.h
//  day15-ui-quartz2d
//
//  Created by apple on 15/10/10.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFView02 : UIView

@property (nonatomic,strong)UIImage  *img;

-(instancetype)initWithImg:(UIImage *)img;
@end
