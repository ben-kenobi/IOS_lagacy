gcc shell.c sqlite3.c -lpthread -ldl -o sqlite

