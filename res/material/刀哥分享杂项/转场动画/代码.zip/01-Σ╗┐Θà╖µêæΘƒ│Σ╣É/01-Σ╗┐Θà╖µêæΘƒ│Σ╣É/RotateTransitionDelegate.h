//
//  RotateTransitionDelegate.h
//  01-仿酷我音乐
//
//  Created by 刘凡 on 15/11/11.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <UIKit/UIKit.h>

/// 转场动画代理
@interface RotateTransitionDelegate : NSObject <UIViewControllerTransitioningDelegate, UIViewControllerAnimatedTransitioning>

@end
