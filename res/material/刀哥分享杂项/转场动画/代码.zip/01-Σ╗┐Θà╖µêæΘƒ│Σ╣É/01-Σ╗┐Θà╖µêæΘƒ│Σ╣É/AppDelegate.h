//
//  AppDelegate.h
//  01-仿酷我音乐
//
//  Created by 刘凡 on 15/11/10.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

