# 交互式转场演练

## 目标

仿酷我音乐播放器效果

## 功能分析

1. 手势识别处理视图旋转
2. 自定义 Modal 转场

![](力学示意图.png)

## 代码实现

### 1. 处理视图旋转

* 获得当前视图旋转角度

```objc
CGFloat viewAngle = atan2(transform.b, transform.a);
```

* 转换 x/y 方向的的力量

```objc
CGFloat dx = point.x * cos(viewAngle);
CGFloat dy = point.y * sin(viewAngle);
```

* 设置视图 transform

```objc
CGFloat angle = (dx + dy) / self.view.bounds.size.width;
transform = CGAffineTransformRotate(transform, angle);
```

* 增加水平位移

```objc
transform.tx += 2 * (dx + dy);
```

* transform 的属性

```objc
/**
 struct CGAffineTransform {
     CGFloat a, b, c, d;
     CGFloat tx, ty;
 };
 
 tx / ty 处理位移的
 a / d 是处理缩放比例的
 a / b / c / d 共同处理旋转角度的
 */
```

#### 定位点

* 图层的 `anchorPoint` 属性范围从 0.0~1.0，可以设置视图的定位点
* 使用 `anchorPoint` 不需要关心视图的宽高
* 视图的旋转形变是以 `anchorPoint` 为中心点进行的

> 注意：应该先设置 `anchorPoint`，再设置 `frame` 属性

### 2. 自定义 Modal 转场

* 自定义转场动画示意图

![](动画转场.png)

* 设置 modal 转场类型

```objc
// 设置 modal 转场类型
vc.modalPresentationStyle = UIModalPresentationCustom;
```

> 将 modal 转场类型设置为 Custom 之后，在 Modal 展现目标视图控制器后，源视图控制器的视图不会从屏幕上移出

* 设置转场动画代理

```objc
// 设置转场(转换场景)动画代理
vc.transitioningDelegate = self.rotateDelegate;
```

> 转场动画代理负责提供实现 `Modal` / `Dismiss` 转场动画的对象

```objc
/// 返回提供 modal 转场动画的对象
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    
    return self;
}
```

* 遵守 `UIViewControllerAnimatedTransitioning` 协议实现动画方法

* 转场动画的动画时长

```objc
/// 转场动画的动画时长
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}
```

* 转场动画细节

```objc
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    // 容器视图
    UIView *containerView = [transitionContext containerView];
    
    // 目标视图
    UIView *toView = [transitionContext viewForKey:UITransitionContextToViewKey];
    
    [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    
    // 设置初始形变
    toView.transform = CGAffineTransformMakeRotation(-M_PI_2);
    
    // 将目标视图添加到容器视图中
    [containerView addSubview:toView];
    
    [UIView animateWithDuration:[self transitionDuration:transitionContext]
                          delay:0.0
         usingSpringWithDamping:0.8
          initialSpringVelocity:10
                        options:0
                     animations:^{
                         
                         // 恢复视图的形变
                         toView.transform = CGAffineTransformIdentity;
                         
                     } completion:^(BOOL finished) {
                         
                         // 转场动画的末尾必须调用的方法，告诉视图控制器转场动画已经结束，否则系统会一直等待转场动画进行！
                         [transitionContext completeTransition:YES];
                     }];
    
}
```


