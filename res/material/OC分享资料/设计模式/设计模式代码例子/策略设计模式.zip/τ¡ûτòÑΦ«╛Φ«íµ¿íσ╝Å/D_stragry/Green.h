//
//  Green.h
//  D_stragry
//
//  Created by qrh on 14-3-11.
//  Copyright (c) 2014年 qrh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IStragry.h"

@interface Green : NSObject<IStragry>

@end
