//
//  Backdoor.m
//  D_stragry
//
//  Created by qrh on 14-3-11.
//  Copyright (c) 2014年 qrh. All rights reserved.
//

#import "Backdoor.h"

@implementation Backdoor

- (void)run{
    NSLog(@"backdoor");
}

@end
