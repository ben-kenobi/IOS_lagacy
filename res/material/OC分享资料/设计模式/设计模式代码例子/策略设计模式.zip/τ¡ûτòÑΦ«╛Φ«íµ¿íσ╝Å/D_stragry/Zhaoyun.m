//
//  Zhaoyun.m
//  D_stragry
//
//  Created by qrh on 14-3-11.
//  Copyright (c) 2014年 qrh. All rights reserved.
//

#import "Zhaoyun.h"

@implementation Zhaoyun
- (void)didRun:(id<IStragry>)run{
    [run run];
}
@end
