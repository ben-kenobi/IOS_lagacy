//
//  Green.m
//  D_stragry
//
//  Created by qrh on 14-3-11.
//  Copyright (c) 2014年 qrh. All rights reserved.
//

#import "Green.h"

@implementation Green
- (void)run{
    NSLog(@"green");
}
@end
