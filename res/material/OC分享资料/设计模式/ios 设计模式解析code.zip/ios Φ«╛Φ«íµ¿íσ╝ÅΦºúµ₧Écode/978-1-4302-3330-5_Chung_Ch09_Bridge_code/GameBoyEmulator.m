//
//  GameBoyEmulator.m
//  Bridge
//
//  Created by Carlo Chung on 11/26/10.
//  Copyright 2010 Carlo Chung. All rights reserved.
//

#import "GameBoyEmulator.h"


@implementation GameBoyEmulator

- (void) loadInstructionsForCommand:(ConsoleCommand) command
{
	// load specific instructions for
	// the Game Boy
}

- (void) executeInstructions
{
	// execute loaded instructions
}

@end
