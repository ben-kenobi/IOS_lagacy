//
//  ScribbleThumbnail.m
//  TouchPainter
//
//  Created by Carlo Chung on 10/18/10.
//  Copyright 2010 Carlo Chung. All rights reserved.
//

#import "ScribbleThumbnailView.h"


@implementation ScribbleThumbnailView

@dynamic image;
@dynamic scribble;
@synthesize imagePath=imagePath_;
@synthesize scribblePath=scribblePath_;

@end
