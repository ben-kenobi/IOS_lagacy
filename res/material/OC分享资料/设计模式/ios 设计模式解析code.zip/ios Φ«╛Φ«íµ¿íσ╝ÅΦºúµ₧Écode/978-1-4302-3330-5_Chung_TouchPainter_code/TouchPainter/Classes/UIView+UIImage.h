//
//  UIView+UIImage.h
//  TouchPainter
//
//  Created by Carlo Chung on 10/23/10.
//  Copyright 2010 Carlo Chung. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIView (UIImage)

- (UIImage*) image;

@end
