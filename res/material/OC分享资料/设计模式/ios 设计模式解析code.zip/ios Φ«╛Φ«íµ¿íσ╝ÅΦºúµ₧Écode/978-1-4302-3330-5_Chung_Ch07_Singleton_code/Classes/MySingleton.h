//
//  MySingleton.h
//  Singleton
//
//  Created by Carlo Chung on 2/17/11.
//  Copyright 2011 Carlo Chung. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"



@interface MySingleton : Singleton
{

}

@end
