//
//  RootViewController.m
//  D_tran
//
//  Created by hyde2013 on 13-4-2.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import "RootViewController.h"
#import <QuartzCore/QuartzCore.h>
@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    layer=[CALayer layer];
    CGColorRef color;
    color=[UIColor blueColor].CGColor;
    [layer setBackgroundColor:color];
    [layer setFrame:self.view.frame];
    [[self.view layer]insertSublayer:layer atIndex:0];
    
    workLayer=[CALayer layer];
    color=[UIColor colorWithRed:0.5f green:0.5f blue:0.5f alpha:1.0].CGColor ;
    [workLayer setBackgroundColor:color];
    [workLayer setCornerRadius:5.0f];
    
    color=[UIColor colorWithRed:0.0f green:1.0f blue:0.0f alpha:1.0f].CGColor;
    [workLayer setBorderColor:color];
    [workLayer setBorderWidth:2.0f];
    
    CGRect workFrame=[layer bounds];
    workFrame.origin.x=workFrame.size.width / 4;
    workFrame.origin.y = workFrame.size.height / 4;
    workFrame.size.width /= 2;
    workFrame.size.height /= 2;
    
    [workLayer setAnchorPoint:CGPointMake(0, 0)];
    [workLayer setFrame:workFrame];
    [layer addSublayer:workLayer];
    
    UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setTitle:@"scale" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(abc) forControlEvents:UIControlEventTouchUpInside];
    button.frame=CGRectMake(0, 440, 50, 20);
    [self.view addSubview:button];
    
    UIButton *button1=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button1 setTitle:@"rotate" forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(rotate) forControlEvents:UIControlEventTouchUpInside];
    button1.frame=CGRectMake(100, 440, 50, 20);
    [self.view addSubview:button1];
    
    UIButton *button2=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button2 setTitle:@"scale" forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(rotate3D) forControlEvents:UIControlEventTouchUpInside];
    button2.frame=CGRectMake(200, 440, 50, 20);
    [self.view addSubview:button2];
    
}

-(void)abc
{
    NSValue *value = nil;
    CABasicAnimation *animation = nil;
    CATransform3D transform;
    
    [ workLayer removeAllAnimations];
    animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    transform = CATransform3DMakeScale(0.5f, 0.5f, 1.0f);
    value = [NSValue valueWithCATransform3D:transform];
    [animation setToValue:value];
    transform = CATransform3DMakeScale(1.0f, 1.0f, 1.0f);
    value = [NSValue valueWithCATransform3D:transform];
    [animation setFromValue:value];
    
    [animation setAutoreverses:YES];
    [animation setDuration:1.0f];
    [animation setRepeatCount:100];
    
    [workLayer addAnimation:animation forKey:@"kScaleKey"];
}

-(void)rotate
{
    NSValue *value = nil;
    CABasicAnimation *animation = nil;
    CATransform3D transform;
    
    [workLayer  removeAllAnimations];
    animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    transform = CATransform3DMakeRotation(1.57f, 0.0f, 0.0f, 1.0f);
    value = [NSValue valueWithCATransform3D:transform];
    [animation setToValue:value];
    transform = CATransform3DMakeRotation(0.0f, 0.0f, 0.0f, 1.0f);
    value = [NSValue valueWithCATransform3D:transform];
    [animation setFromValue:value];
    [animation setAutoreverses:YES];
    [animation setDuration:1.0f];
    [animation setRepeatCount:100];
    [workLayer addAnimation:animation forKey:@"kScaleKeyl"];
}
-(void)rotate3D
{
    NSValue *value = nil;
    CABasicAnimation *animation = nil;
    CATransform3D transform;
    
    [ workLayer removeAllAnimations];
    animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    transform = CATransform3DMakeRotation(1.57f, 1.0f, 1.0f, 0.0f);
    value = [NSValue valueWithCATransform3D:transform];
    [animation setToValue:value];
    transform = CATransform3DMakeRotation(0.0f, 1.0f, 1.0f, 0.0f);
    value = [NSValue valueWithCATransform3D:transform];
    [animation setFromValue:value];
    [animation setAutoreverses:YES];
    [animation setDuration:1.0f];
    [animation setRepeatCount:100];
    [workLayer addAnimation:animation forKey:@"kkScaleKey"];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
