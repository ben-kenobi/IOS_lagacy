//
//  main.m
//  D_tran
//
//  Created by hyde2013 on 13-4-2.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
