//
//  main.m
//  D_CAContents
//
//  Created by hyde2013 on 13-4-1.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
