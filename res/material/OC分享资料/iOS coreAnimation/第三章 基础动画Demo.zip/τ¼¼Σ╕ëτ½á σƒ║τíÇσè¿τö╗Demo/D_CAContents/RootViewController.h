//
//  RootViewController.h
//  D_CAContents
//
//  Created by hyde2013 on 13-4-1.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#import "SecondViewController.h"
@interface RootViewController : UIViewController
{

    CALayer *layer;
    CALayer *tempLayer;
    UIButton *button1;
    UIView *view2;
    float x;
    float y;
    float width;
    float height;
    BOOL isTap;
    BOOL secondTap;
}
@property float x;
@property float y;
@property float width;
@property float height;

- (CGImageRef)nsImageToCGImageRef:(UIImage*)image;

@end
