//
//  RootViewController.m
//  D_CAContents
//
//  Created by hyde2013 on 13-4-1.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.frame=CGRectMake(0, 0, 50, 30);
    [button addTarget:self action:@selector(abc) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 60, 320, 100)];
    imageView.userInteractionEnabled=YES;
    [self.view addSubview:imageView];
	// Do any additional setup after loading the view.
    NSString *path=[[NSBundle mainBundle]pathForResource:@"balloon" ofType:@"jpg"];
    UIImage *image=[[UIImage alloc]initWithContentsOfFile:path];
    layer=[CALayer layer];
    
    x=0;
    y=0;
    width=320;
    height=300;
    
    [layer setFrame:CGRectMake(x, y, width, height)];
    // Set the layer contents to our baloon image.
    [layer setContents:(id)[self nsImageToCGImageRef:image]];
    // Add our layer to the sublayers at index 0 so that is displays
    // behind the controls we added
    [[imageView layer]insertSublayer:layer atIndex:0];
    [image release];
    isTap = NO;
    secondTap=NO;
    
    NSString *path1=[[NSBundle mainBundle]pathForResource:@"balloon" ofType:@"jpg"];
    UIImage *image1=[[UIImage alloc]initWithContentsOfFile:path1];
    tempLayer=[CALayer layer];
    [tempLayer setFrame:CGRectMake(100, 0, 50, 40)];
    [tempLayer setContents:(id)[self nsImageToCGImageRef:image1]];
    [[imageView layer]insertSublayer:tempLayer atIndex:1];
    
    
    
    button1=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    button1.frame=CGRectMake(0, 50, 50, 30);
    [button1 setTitle:@"second" forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(secondButtonBasicAnimation) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    
    
    UIButton *button2=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    button2.frame=CGRectMake(100, 0, 50, 30);
    [button2 setTitle:@"third" forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(thirdButtonTap) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    view2=[[UIView alloc]initWithFrame:CGRectMake(200, 0, 50, 30)];
    view2.backgroundColor=[UIColor redColor];
    [self.view addSubview:view2];

    
}

-(void)abc
{
    if (isTap==YES)
    {
        isTap=NO;
        x=0;
        y=0;
        width=320;
        height=300;
        [layer setSpeed:0.5];
        [layer setFrame:CGRectMake(x, y, width, height)];
        [tempLayer setFrame:CGRectMake(100, 0, 50, 40)];
 
    }
    else
    {
        isTap=YES;
        x=0;y= 0;width= 320;height= 0;
         [layer setSpeed:0.1];
        [layer setFrame:CGRectMake(x, y, width, height)];
        [tempLayer setFrame:CGRectMake(100, 0, 50, 0)];

    }
}


-(CGImageRef)nsImageToCGImageRef:(UIImage *)image
{
    CGImageRef ref=image.CGImage;
    return ref;
}

-(CABasicAnimation *)backgroundColorAnimation
{
    CABasicAnimation *anim=[CABasicAnimation animationWithKeyPath:@"backgroundColorAnimation"];
    [anim setDuration:5.0];

    CGColorRef red = [UIColor redColor].CGColor;
    CGColorRef green = [UIColor greenColor].CGColor;
    
    [anim setFromValue:(id)red];
    [anim setToValue:(id)green];
    
    CFRelease(red);
    CFRelease(green);
    return anim;
}

-(void)secondButtonBasicAnimation
{
    CGPoint startPoint=CGPointMake(280, 300);
    CGPoint endPoint=CGPointMake(30, 50);
    CABasicAnimation *animation =
    [CABasicAnimation animationWithKeyPath:@"position"];
    if (secondTap==YES)
    {
        secondTap=NO;
        
        [animation setFromValue:[NSValue valueWithCGPoint:startPoint]];
        [animation setToValue:[NSValue valueWithCGPoint:endPoint]];
        [animation setDuration:5.0];
        [animation setFillMode:kCAFillModeForwards];
        [[button1 layer] setPosition:endPoint];        
        [[button1 layer]addAnimation:animation forKey:@"button"];
        
        
    }
    else
    {
        secondTap = YES;
        [animation setFromValue:[NSValue valueWithCGPoint:endPoint]];
        [animation setToValue:[NSValue valueWithCGPoint:startPoint]];
        [animation setDuration:5.0];
        [animation setFillMode:kCAFillModeForwards];
        [[button1 layer] setPosition:startPoint];
        [[button1 layer]addAnimation:animation forKey:@"button"];
       
    }
    
}

-(void)thirdButtonTap
{
//    [CATransaction begin];
//    [CATransaction setValue:[NSNumber numberWithInt:5] forKey:kCATransitionPush];
//    [[view2 layer]setPosition:CGPointMake(100, 200)];
//    [CATransaction commit];
    CGRect oldRect=CGRectMake(0, 0, 100, 100);
    CGRect newRect=CGRectMake(0, 0, 300, 300);
    
    CABasicAnimation *boundsAnimation=[CABasicAnimation animationWithKeyPath:@"bounds"];
    [boundsAnimation setFromValue:[NSValue valueWithCGRect:oldRect]];
    [boundsAnimation setToValue:[NSValue valueWithCGRect:newRect]];
    [boundsAnimation setDuration:15.0f];
    [boundsAnimation setBeginTime:0.0f];
    
    CABasicAnimation *positionAnimation=[CABasicAnimation animationWithKeyPath:@"position"];
    [positionAnimation setFromValue:[NSValue valueWithCGRect:[view2 layer].frame]];
    [positionAnimation setToValue:[NSValue valueWithCGPoint:CGPointMake(0, 0)]];
    [positionAnimation setDuration:15.0f];
    [positionAnimation setBeginTime:5.0f];
    
    CABasicAnimation *borderWidthAnimation =
    [CABasicAnimation animationWithKeyPath:@"borderWidth"];
    [borderWidthAnimation setFromValue:[NSNumber numberWithFloat:5.0f]];
    [borderWidthAnimation setToValue:[NSNumber numberWithFloat:30.0f]];
    [borderWidthAnimation setDuration:15.0f];
    [borderWidthAnimation setBeginTime:10.0f];
    
    CAAnimationGroup *group=[CAAnimationGroup animation];
    [group setDuration:15];
    [group setAnimations:[NSArray arrayWithObjects:boundsAnimation,positionAnimation,borderWidthAnimation, nil]];
    [[view2 layer]addAnimation:group forKey:nil];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
