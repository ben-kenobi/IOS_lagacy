//
//  RootViewController.m
//  D_animation
//
//  Created by hyde2013 on 13-4-2.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    starPath = CGPathCreateMutable();
    CGPathMoveToPoint(starPath,NULL,160.0, 280.0);
    
    starLayer =[[CALayer alloc]init];
    [starLayer setBackgroundColor:[[UIColor yellowColor] CGColor]];
    [starLayer setDelegate:self];
    [starLayer setFrame:[[[self view] layer] frame]];
    
    dotLayer =[CALayer layer];
    [dotLayer setPosition:CGPointMake(160.0, 280.0)];
    [dotLayer setCornerRadius:5.0];
    [dotLayer setBackgroundColor:[UIColor redColor].CGColor];
    [dotLayer setBounds:CGRectMake(0, 0, 10.0, 10.0)];
    
    [starLayer insertSublayer:dotLayer atIndex:0];
    
    [[self.view layer]insertSublayer:starLayer atIndex:0];
    
    UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button addTarget:self action:@selector(abc) forControlEvents:UIControlEventTouchUpInside];
    button.frame=CGRectMake(100, 400, 50, 30);
    [self.view addSubview:button];
}

-(void)abc
{
    if (starPath)
    {
        CFRelease(starPath);
        starPath = CGPathCreateMutable();
        CGPathMoveToPoint(starPath,NULL,160.0, 260.0);
        [starLayer displayIfNeeded];
    }
    
    //define a path for the star shape
    //define path
    CGMutablePathRef path=CGPathCreateMutable();
    //start point
    CGPathMoveToPoint(path,NULL,160.0, 280.0);
    
    CGPathAddLineToPoint(path, NULL, 101.0, 79.0);
    CGPathAddLineToPoint(path, NULL, 255.0, 190.0);
    CGPathAddLineToPoint(path, NULL, 64.0, 190.0);
    CGPathAddLineToPoint(path, NULL, 218.0, 79.0);
    //closesubpath
    CGPathCloseSubpath(path);
    
    CAKeyframeAnimation *animation=[CAKeyframeAnimation animationWithKeyPath:@"position"];
    [animation setDuration:10.0];
    [animation setDelegate:self];
    [animation setPath:path];
    
    //release the path
    CFRelease(path);
    //add animation to layer
    [dotLayer addAnimation:animation forKey:@"position"];
    
    //add schedule
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(legOne:)
                                   userInfo:nil
                                    repeats:NO];
    
	[NSTimer scheduledTimerWithTimeInterval:4.0
                                     target:self
                                   selector:@selector(legTwo:)
                                   userInfo:nil
                                    repeats:NO];
    
	[NSTimer scheduledTimerWithTimeInterval:6.0
                                     target:self
                                   selector:@selector(legThree:)
                                   userInfo:nil
                                    repeats:NO];
    
	[NSTimer scheduledTimerWithTimeInterval:8.0
                                     target:self
                                   selector:@selector(legFour:)
                                   userInfo:nil
                                    repeats:NO];
    
	[NSTimer scheduledTimerWithTimeInterval:10.0
                                     target:self
                                   selector:@selector(legFive:)
                                   userInfo:nil
                                    repeats:NO];
    
    // Tell the root layer to call drawLayer
    [starLayer setNeedsDisplay];

    
    
}

- (void)legOne:(id)sender
{
    CGPathAddLineToPoint(starPath, NULL, 101.0, 79.0);
    [starLayer setNeedsDisplay];
}
- (void)legTwo:(id)sender
{
    CGPathAddLineToPoint(starPath, NULL, 255.0, 190.0);
    [starLayer setNeedsDisplay];
}
- (void)legThree:(id)sender
{
    CGPathAddLineToPoint(starPath, NULL, 64.0, 190.0);
    [starLayer setNeedsDisplay];
}
- (void)legFour:(id)sender
{
    CGPathAddLineToPoint(starPath, NULL, 218.0, 79.0);
    [starLayer setNeedsDisplay];
}

- (void)legFive:(id)sender
{
    CGPathCloseSubpath(starPath);
    [starLayer setNeedsDisplay];
}


- (void)drawLayer:(CALayer *)layer
        inContext:(CGContextRef)context
{
    
    if( layer == starLayer )
    {
        CGContextSetStrokeColorWithColor(context, [[UIColor blueColor] CGColor]);
        
        CGContextBeginPath(context);
        CGContextAddPath(context, starPath);
        
        CGContextSetLineWidth(context, 3.0);
        
        CGContextStrokePath(context);
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
