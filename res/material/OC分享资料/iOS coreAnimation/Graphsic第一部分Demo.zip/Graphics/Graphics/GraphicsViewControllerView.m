//
//  GraphicsViewControllerView.m
//  Graphics
//
//  Created by hyde2013 on 13-3-29.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import "GraphicsViewControllerView.h"

@implementation GraphicsViewControllerView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setBackgroundColor:[UIColor grayColor]];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    UIFont *helveticaBold=[UIFont fontWithName:@"HelveticaNeue-Bold" size:40.f];
    NSString *myString=@"Some String";
    [myString drawAtPoint:CGPointMake(50, 50) withFont:helveticaBold];
    
    /* Load the color */
    UIColor *magentaColor =
    [UIColor colorWithRed:0.5f green:0.0f blue:0.5f alpha:1.0f];
    /* Set the color in the graphical context */
    [magentaColor set];
    /* Load the font */
    UIFont *helveticaBold1 =
    [UIFont fontWithName:@"HelveticaNeue-Bold" size:30.0f];
    /* Our string to be drawn */
    NSString *myString1 = @"I Learn Really Fast";
    /* Draw the string using the font. The color has already been set */
    [myString1 drawAtPoint:CGPointMake(25, 190) withFont:helveticaBold1];
//    [myString1 drawInRect:CGRectMake(100, // X
//                                    120,// Y
//                                    100,// Width
//                                    200)// Height
//                 withFont:helveticaBold];
    
    UIImage *image = [UIImage imageNamed:@"xcode.png"];
    if (image != nil){
        NSLog(@"Successfully loaded the image.");
    } else {
        NSLog(@"Failed to load the image.");
    }
   // [image drawAtPoint:CGPointMake(25, 240)];
    
    //
    [[UIColor brownColor]set];
    /* Get the current graphics context */
    CGContextRef context=UIGraphicsGetCurrentContext();
    /* Set the width for the line */
    CGContextSetLineWidth(context, 5.f);
    /* Start the line at this point */
    CGContextMoveToPoint(context, 50.0f, 10.0f);
    CGContextAddLineToPoint(context, 100.f, 200.f);
    /* Use the context's current color to draw the line */
    CGContextStrokePath(context);
    
    
    [self drawRooftopAtTopPointof:CGPointMake(160.0f, 40.0f) textToDisplay:@"Miter"
                         lineJoin:kCGLineJoinMiter];
    [self drawRooftopAtTopPointof:CGPointMake(160.0f, 180.0f) textToDisplay:@"Bevel"
                         lineJoin:kCGLineJoinBevel];
    [self drawRooftopAtTopPointof:CGPointMake(160.0f, 320.0f) textToDisplay:@"Round"
                         lineJoin:kCGLineJoinRound];
    
    [self mutableLine];
    
}

- (void) drawRooftopAtTopPointof:(CGPoint)paramTopPoint textToDisplay:(NSString *)paramText lineJoin:(CGLineJoin)paramLineJoin
{
    //
    [[UIColor redColor]set];
    
    //
    CGContextRef current=UIGraphicsGetCurrentContext();
    
    //
    CGContextSetLineWidth(current, 20.f);
    
    //
    CGContextMoveToPoint(current, paramTopPoint.x-140, paramTopPoint.y+100);
    
    //
    CGContextAddLineToPoint(current, paramTopPoint.x, paramTopPoint.y);
    
    //
    CGContextAddLineToPoint(current, paramTopPoint.x+100, paramTopPoint.y+140);
    
    //
    CGContextSetMiterLimit(current, paramLineJoin);
    
    //
    CGContextStrokePath(current);
    
    [paramText drawAtPoint:CGPointMake(paramTopPoint.x-40.f, paramTopPoint.y+60.f) withFont:[UIFont boldSystemFontOfSize:30.f]];
    
    
}

-(void)mutableLine
{
    CGMutablePathRef path=CGPathCreateMutable();
    
    //
    CGRect screenBounds=[[UIScreen mainScreen]bounds];
    
    
    //
    CGPathMoveToPoint(path, NULL, screenBounds.origin.x, screenBounds.origin.y);
    //
    CGPathAddLineToPoint(path, NULL, screenBounds.size.width, screenBounds.size.height);
    
    /* Start another line from top-right */
    CGPathMoveToPoint(path, NULL, screenBounds.size.width, screenBounds.origin.y);
    CGPathAddLineToPoint(path, NULL, screenBounds.origin.x, screenBounds.size.height);
    
    CGContextRef currentContext=UIGraphicsGetCurrentContext();
    CGContextAddPath(currentContext, path);
    [[UIColor blueColor]setStroke];
    CGContextDrawPath(currentContext, kCGPathStroke);
    CGPathRelease(path);
}












@end
