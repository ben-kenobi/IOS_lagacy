//
//  ViewController.m
//  Graphics
//
//  Created by hyde2013 on 13-3-29.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import "ViewController.h"
#import "GraphicsViewControllerView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    GraphicsViewControllerView *newView=[[GraphicsViewControllerView alloc]initWithFrame:CGRectMake(0, 0, 320, 460)];
    //[newView setNeedsDisplay];
    [self.view addSubview:newView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
