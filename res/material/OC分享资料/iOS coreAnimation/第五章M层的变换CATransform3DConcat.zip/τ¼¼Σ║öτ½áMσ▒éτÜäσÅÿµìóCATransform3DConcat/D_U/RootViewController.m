//
//  RootViewController.m
//  D_U
//
//  Created by hyde2013 on 13-4-2.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    CALayer *rootLayer=[CALayer layer];
    [rootLayer setFrame:self.view.frame];
    CGColorRef color;
    color=[UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:1.0f].CGColor;
    [rootLayer setBackgroundColor:color];
    [[self.view layer]addSublayer:rootLayer];
    
    layer=[CALayer layer];
    color=[UIColor colorWithRed:0.5f green:0.5f blue:0.5f alpha:1.f].CGColor;
    [layer setBackgroundColor:color];
    [layer setCornerRadius:5.0f];
    color=[UIColor colorWithRed:0.0f green:1.0f blue:1.0f alpha:1.0f].CGColor;
    [layer setBorderColor:color];
    [layer setBorderWidth:2.0f];
    [layer setBounds:CGRectMake(0, 0, 100, 100)];
    [layer setPosition:CGPointMake(55, 55)];
    [rootLayer addSublayer:layer];
    
    UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setTitle:@"scale" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(abc) forControlEvents:UIControlEventTouchUpInside];
    button.frame=CGRectMake(0, 440, 50, 20);
    [self.view addSubview:button];
}

-(void)abc
{
    CGRect frame=self.view.frame;
    float x = frame.origin.x + frame.size.width - 30;
    float y = frame.origin.y + frame.size.height - 30;
    CATransform3D rotate;
    CATransform3D scale;
    CATransform3D combine;
    [CATransaction begin];
    [CATransaction setValue:[NSNumber numberWithFloat:5.0] forKey:kCATransactionAnimationDuration];
    [layer setPosition:CGPointMake(x, y)];
    
    scale=CATransform3DMakeScale(0.1f, 0.1f, 1.0f);
    rotate =CATransform3DMakeRotation(1.57f, 0.0f, 0.0f, 1.0f);
//    [layer setTransform:scale];
//    [layer setTransform:rotate];
    combine=CATransform3DConcat(scale, rotate);
    [layer setTransform:combine];
    [CATransaction commit];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
