//
//  AppDelegate.h
//  D_U
//
//  Created by hyde2013 on 13-4-2.
//  Copyright (c) 2013年 haide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
