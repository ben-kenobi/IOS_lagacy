//
//  FFCounterButton.h
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/18.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <UIKit/UIKit.h>

/// 计数器按钮
@interface FFCounterButton : UIButton

/// 选中计数
@property (nonatomic) NSInteger count;

@end
