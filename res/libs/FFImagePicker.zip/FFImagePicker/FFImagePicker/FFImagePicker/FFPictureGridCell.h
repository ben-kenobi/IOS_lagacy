//
//  FFPictureGridCell.h
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/18.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

@protocol FFPictureGridCellDelegate;

#pragma mark - 照片 cell
@interface FFPictureGridCell : UICollectionViewCell
/// 图片资源
@property (nonatomic) PHAsset *asset;
/// 照片 Cell 代理
@property (nonatomic, weak) id<FFPictureGridCellDelegate> delegate;
/// 是否选中状态
@property (nonatomic, readonly) BOOL isSelected;
/// 点击选中按钮
- (void)clickSelectedButton;
@end

#pragma mark - 照片 cell 协议
@protocol FFPictureGridCellDelegate <NSObject>

/// 照片 cell 选中照片
///
/// @param cell     照片 cell
/// @param selected 是否选中
- (void)pictureGridCell:(FFPictureGridCell *)cell didSelected:(BOOL)selected;

@end