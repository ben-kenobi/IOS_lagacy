//
//  FFPageDetailViewController.h
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/18.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PHAsset;

@interface FFPageDetailViewController : UIViewController

/// 图像索引
@property (nonatomic) NSInteger index;
/// 图片资源
@property (nonatomic) PHAsset *asset;

@end
