//
//  FFAlbum.h
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/18.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>

/// 相册模型 - 管理具体的某一个相册
@interface FFAlbum : NSObject

/// 使用资源集合实例化相册
- (instancetype)initWithCollection:(PHAssetCollection *)collection;
+ (instancetype)albumWithCollection:(PHAssetCollection *)collection;

/// 相册标题
@property (nonatomic, readonly) NSString *title;
/// 相册照片数量
@property (nonatomic, readonly) NSInteger count;

/// 返回指定索引的资源对象
- (PHAsset *)assetWithIndex:(NSInteger)index;

@end
