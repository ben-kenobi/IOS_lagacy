//
//  FFPictureGridViewController.h
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/17.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FFAlbumManager;
@protocol FFPictureGridViewControllerDelegate;

#pragma mark - 照片网格选择控制器
@interface FFPictureGridViewController : UICollectionViewController
/// 照片选择代理
@property (nonatomic, weak) id<FFPictureGridViewControllerDelegate> delegate;
/// 相册管理器
@property (nonatomic) FFAlbumManager *albumManager;
/// 最大选择照片数量，默认 9 张
@property (nonatomic) NSInteger maxPickerCount;
@end

#pragma mark - 照片网格选择控制器协议

@protocol FFPictureGridViewControllerDelegate <NSObject>

/// 选择照片完成
- (void)pictureGridViewControllerDidFinished:(FFPictureGridViewController *)controller;

@end