//
//  FFPictureGridLayout.m
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/17.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import "FFPictureGridLayout.h"

#pragma mark - 常量定义
/// 最小 Cell 宽高
static NSInteger kFFGridCellMinWH = 100;

@implementation FFPictureGridLayout

- (void)prepareLayout {
    [super prepareLayout];
    
    NSInteger colCount = 3;
    CGSize size = self.collectionView.bounds.size;
    // 间距
    CGFloat margin = 5;
    // Cell 宽高
    CGFloat itemWH = [self itemWHWith:size count:colCount margin:margin];
    
    self.itemSize = CGSizeMake(itemWH, itemWH);
    self.minimumInteritemSpacing = margin;
    self.minimumLineSpacing = margin;
    self.sectionInset = UIEdgeInsetsMake(margin, margin, margin, margin);
}

- (CGFloat)itemWHWith:(CGSize)size count:(CGFloat)count margin:(CGFloat)margin {
    CGFloat itemWH = (size.width - (count + 1) * margin) / count;
    
    // 如果大于最小 cell 宽高就递归调用
    if (itemWH > kFFGridCellMinWH) {
        itemWH = [self itemWHWith:size count:count + 1 margin:margin];
    }
    
    return itemWH;
}

@end
