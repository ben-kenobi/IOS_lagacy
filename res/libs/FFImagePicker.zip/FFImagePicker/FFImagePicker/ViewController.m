//
//  ViewController.m
//  FFImagePicker
//
//  Created by 刘凡 on 15/12/17.
//  Copyright © 2015年 joyios. All rights reserved.
//

#import "ViewController.h"
#import "FFImagePickerController.h"

@interface ViewController () <FFImagePickerControllerDelegate>
@property (nonatomic) NSArray *pictures;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}
- (IBAction)clickButton:(id)sender {
    FFImagePickerController *picker = [[FFImagePickerController alloc] init];
    picker.pickerDelegate = self;
    picker.targetSize = CGSizeMake(500, 500);
    picker.maxPickerCount = 5;
    
    [self presentViewController:picker animated:YES completion:nil];
}

#pragma mark - FFImagePickerControllerDelegate
- (void)imagePickerController:(FFImagePickerController *)picker didFinishSelectedPictures:(NSArray<UIImage *> *)pictures {
    NSLog(@"%@", pictures);
    self.pictures = pictures;
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
