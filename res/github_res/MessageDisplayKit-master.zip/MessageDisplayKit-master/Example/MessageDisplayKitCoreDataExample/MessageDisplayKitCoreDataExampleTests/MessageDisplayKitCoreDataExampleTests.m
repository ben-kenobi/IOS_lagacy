//
//  MessageDisplayKitCoreDataExampleTests.m
//  MessageDisplayKitCoreDataExampleTests
//
//  Created by 曾 宪华 on 14-5-29.
//  Copyright (c) 2014年 曾宪华 QQ群: (142557668) QQ:543413507  Gmail:xhzengAIB@gmail.com. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface MessageDisplayKitCoreDataExampleTests : XCTestCase

@end

@implementation MessageDisplayKitCoreDataExampleTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
