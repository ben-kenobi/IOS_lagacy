//
//  SDDiscoverTableViewHeaderItemButton.h
//  GSD_ZHIFUBAO
//
//  Created by aier on 15-6-5.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDDiscoverTableViewHeaderItemButton : UIButton

@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *title;

@end
