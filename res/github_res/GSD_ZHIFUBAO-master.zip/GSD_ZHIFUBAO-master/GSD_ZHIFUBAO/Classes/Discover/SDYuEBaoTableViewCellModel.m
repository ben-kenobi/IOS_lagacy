//
//  SDYuEBaoTableViewCellModel.m
//  GSD_ZHIFUBAO
//
//  Created by aier on 15-6-6.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import "SDYuEBaoTableViewCellModel.h"

@implementation SDYuEBaoTableViewCellModel

@end
