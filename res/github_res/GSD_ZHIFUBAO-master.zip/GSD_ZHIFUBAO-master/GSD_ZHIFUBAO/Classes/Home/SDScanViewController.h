//
//  SDScanViewController.h
//  GSD_ZHIFUBAO
//
//  Created by aier on 15-6-6.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

/**
 
 *******************************************************
 *                                                      *
 * 感谢您的支持， 如果下载的代码在使用过程中出现BUG或者其他问题    *
 * 您可以发邮件到gsdios@126.com 或者 到                       *
 * https://github.com/gsdios?tab=repositories 提交问题     *
 *                                                      *
 *******************************************************
 
 */

#import "SDBasicViewContoller.h"

@interface SDScanViewController : SDBasicViewContoller

@end
