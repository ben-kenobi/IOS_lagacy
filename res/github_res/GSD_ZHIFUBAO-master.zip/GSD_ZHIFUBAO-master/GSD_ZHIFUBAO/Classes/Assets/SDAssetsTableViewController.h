//
//  SDAssetsTableViewController.h
//  GSD_ZHIFUBAO
//
//  Created by aier on 15-6-4.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import "SDBasicTableViewController.h"

@interface SDAssetsTableViewController : SDBasicTableViewController

@end
