//
//  SDGridItemCacheTool.h
//  GSD_ZHIFUBAO
//
//  Created by gsd on 15/8/11.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDGridItemCacheTool : NSObject

+ (NSArray *)itemsArray;
+ (void)saveItemsArray:(NSArray *)array;

@end
