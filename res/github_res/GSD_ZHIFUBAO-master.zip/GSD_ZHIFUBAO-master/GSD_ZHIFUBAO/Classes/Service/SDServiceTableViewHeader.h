//
//  SDServiceTableViewHeader.h
//  GSD_ZHIFUBAO
//
//  Created by aier on 15-6-4.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDServiceTableViewHeader : UIView <UITextFieldDelegate>

@property (nonatomic, copy) NSString *placeholderText;

@end
