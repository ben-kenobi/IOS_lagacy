//
//  WNXHeadCollectionReusableView.h
//  WNXHuntForCity
//
//  Created by MacBook on 15/7/7.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//  UICollectionView的headView

#import <UIKit/UIKit.h>

@interface WNXHeadCollectionReusableView : UICollectionReusableView

@property (nonatomic, strong) UILabel *textLabel;
@property (nonatomic, strong) UIView *lineView;

@end
