//
//  WNXSearchViewController.h
//  WNXHuntForCity
//
//  Created by MacBook on 15/7/3.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//  搜索控制器

#import "WNXShowViewController.h"

@interface WNXSearchViewController : UIViewController

@end
