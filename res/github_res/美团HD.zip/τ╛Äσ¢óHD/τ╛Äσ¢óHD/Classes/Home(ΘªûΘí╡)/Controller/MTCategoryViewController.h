//
//  MTCategoryViewController.h
//  美团HD
//
//  Created by apple on 14/11/23.
//  Copyright (c) 2014年 heima. All rights reserved.
//  分类控制器:显示分类列表

#import <UIKit/UIKit.h>

@interface MTCategoryViewController : UIViewController

@end
