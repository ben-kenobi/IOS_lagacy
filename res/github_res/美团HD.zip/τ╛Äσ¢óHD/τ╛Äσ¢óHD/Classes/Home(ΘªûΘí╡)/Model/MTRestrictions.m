//
//  MTRestrictions.m
//  美团HD
//
//  Created by apple on 14/11/27.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "MTRestrictions.h"
#import "MJExtension.h"

@implementation MTRestrictions
MJCodingImplementation
@end
