//
//  MTBusiness.m
//  美团HD
//
//  Created by apple on 14/11/29.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "MTBusiness.h"
#import "MJExtension.h"

@implementation MTBusiness
MJCodingImplementation
@end
