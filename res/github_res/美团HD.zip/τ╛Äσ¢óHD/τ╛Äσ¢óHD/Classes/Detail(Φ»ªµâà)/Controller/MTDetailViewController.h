//
//  ZTDetailViewController.h
//  团HD
//
//  Created by zt on 15/10/23.
//  Copyright © 2015年 zt. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MTDeal;
@interface MTDetailViewController : UIViewController
@property (nonatomic, strong) MTDeal *deal;
@end
