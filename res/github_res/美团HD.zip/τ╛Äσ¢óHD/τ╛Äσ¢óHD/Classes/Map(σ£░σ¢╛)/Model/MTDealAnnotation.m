//
//  ZTDealAnnotation.m
//  团HD
//
//  Created by zt on 15/10/23.
//  Copyright © 2015年 zt. All rights reserved.
//

#import "MTDealAnnotation.h"

@implementation MTDealAnnotation
- (BOOL)isEqual:(MTDealAnnotation *)other
{
    return [self.title isEqual:other.title];
}
@end
